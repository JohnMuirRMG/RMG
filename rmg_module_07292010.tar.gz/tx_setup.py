#!/usr/bin/env python
#runs the setup script to enter transmitters

import rmg
import wx

app = wx.PySimpleApp()
frame = rmg.rmg_setup.rmg_window(None, wx.ID_ANY, "Transmitter Setup for RMG")

app.MainLoop()
