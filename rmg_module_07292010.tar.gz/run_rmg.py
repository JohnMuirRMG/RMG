#!/usr/bin/env python
#Runs the rmg based on multi.conf

import rmg
#import time

dir_finder = rmg.rmg_run.detector_array()
dir_finder.run()

#dir_finder.start()
#time.sleep(10)
#dir_finder.stop()
#dir_finder.next()
