/*
Accumulator class implements a circular buffer with a stored value for the sum of the buffer's contents
This is treated as a time-matched filter for use by the detector class
*/
//Todd Borrowman ECE-UIUC 2-21-08

#include <accumulator.h>
#include <stdlib.h>

//#include <cstdio>

//Constructor
accumulator::accumulator(int s){

  size = s;
  buffer = (double *)calloc(size,sizeof(double));
  index = 0;
  total_sum = 0.0;
  
  //fbuffer = fopen("buffer.dat","w");
}

//Destructor
accumulator::~accumulator(){
  free(buffer);
  //fclose(fbuffer);
}

//Adds a new value to the buffer and adjusts the total sum
double accumulator::add(double in){



  //calculate sum
  double diff = in - buffer[index];
    //fwrite(&diff,sizeof(float),1,fbuffer);
    //fwrite(&total_sum,sizeof(float),1,fbuffer);
  total_sum = total_sum + diff;
    //fwrite(&total_sum,sizeof(float),1,fbuffer);
  //total_sum = 0.0;
  //for(int j=0;j<size;j++)
    //total_sum += buffer[j];


  //write new value
  buffer[index]=in;

  //increment index and check for overflow
  index++;
  if(index >= size){
    index = 0;
  }
  return total_sum;
}

//Call returns the total sum
double accumulator::value(){
  return total_sum;
}

