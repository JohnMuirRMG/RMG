/*
Peak_detect class implements the peak detection state machine to determine pulse locations
State is returned to df_detect
*/
//Todd Borrowman ECE-UIUC 01/30/08



#include <peak_detect.h>

//#include <cstdio>


//peak_detect::~peak_detect(){
//  fclose(fdata);
//  fclose(favg);
//}




//Constructor
peak_detect::peak_detect(float rise_in, float fall_in, float alpha_in){

  rise=rise_in;
  fall=fall_in;
  alpha=alpha_in;
  state=BELOW_THRESHOLD;
  avg=0.0;
  peak_value=0.0;
//Debug files
  //fdata = fopen("data.dat","w");
  //favg = fopen("avg.dat","w");
  
}



detector_states peak_detect::detect(const float data){
//states are 0-below threashold, 1-above threashold, 2-peak, 3-trigger

  //fwrite(&data,sizeof(const float),1,fdata);
  //fwrite(&avg,sizeof(float),1,favg);

  switch(state){
    case BELOW_THRESHOLD:

      if(data > avg*rise){//trigger
        state=PEAK;
        peak_value=data;
      }
      else{//update avg
        avg=alpha*data+(1-alpha)*avg;
      }
    break;
  
    case ABOVE_THRESHOLD:

      if(data>peak_value){//temporary peak
        state=PEAK;
        peak_value=data;
      }
      else if(data<avg*fall){//fell below threashold
        state=TRIGGER;
      }
    
    break;

    case PEAK:

      if(data>peak_value){//temporary peak
        peak_value=data;
      }
      else if(data<(avg*fall)){//fell below threashold
        state=TRIGGER;
      }
      else{
        state=ABOVE_THRESHOLD;
      }
  
    break;
  
  case TRIGGER:

    if(data>avg*rise){//trigger
      state=PEAK;
      peak_value=data;
    }
    else{//update avg
      avg=alpha*data+(1-alpha)*avg;
      state=BELOW_THRESHOLD;
    }
  }
  return state;
}




