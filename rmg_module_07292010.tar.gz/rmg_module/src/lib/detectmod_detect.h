/*
detectmod_detect class implements a detectore module for gnuradio
input - data stream
output - .det files storing individual detected pulses
*/
//Todd Borrowman ECE-UIUC 01/30/08~02/2010


#ifndef INCLUDED_detectmod_detect_H
#define INCLUDED_detectmod_detect_H

#include <peak_detect.h>
#include <accumulator.h>
#include <circ_buffer.h>
#include <gr_sync_block.h>


class detectmod_detect;

enum module_states {FILL_ACCUMULATOR, DETECT, CONFIRM_PEAK, FILL_BUFFER};


typedef boost::shared_ptr<detectmod_detect> detectmod_detect_sptr;



detectmod_detect_sptr detectmod_make_detect (int pulse_width, int save_width, int channels, char *filename, float rate, float, char);

class detectmod_detect : public gr_sync_block
{
private:

  friend detectmod_detect_sptr detectmod_make_detect (int pulse_width, int save_width, int channels, char *filename, float rate, float center_freq, char);
  
  int acc_length;
  int save_length;
  int p_index;
  int ch;
  int fill_length;
  accumulator *acc;
  circ_buffer *save_holder;
  gr_complex *peak_holder;
  double total;
  peak_detect *pkdet;
  float rate;
  float c_freq;
  char *fileprefix;
  int fill_counter;
  module_states state;
  void	       *d_fp;
  char psd;

  bool pulse_shape_discriminator();
  void write_data(gr_complex *data, int index);
  bool open(const char *filename);
  bool open_file(const char *filename);
  void close();

protected:

  detectmod_detect (int pulse_width, int save_width, int channels,char *filename,float rate, float,char);

public:
  ~detectmod_detect ();	// public destructor

  void rise_factor(float r);
  void fall_factor(float f);
  void alpha_factor(float a);
  void reset();

  int work (int noutput_items,
		    gr_vector_const_void_star &input_items,
		    gr_vector_void_star &output_items);

};

#endif /* INCLUDED_detectmod_detect_h*/
