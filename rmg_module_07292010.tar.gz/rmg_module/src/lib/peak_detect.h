/*
Peak_detect class implements the peak detection state machine to determine pulse locations
State is returned to df_detect
*/
//Todd Borrowman ECE-UIUC 01/18/08

//#include <cstdio>

enum detector_states {BELOW_THRESHOLD, ABOVE_THRESHOLD, PEAK, TRIGGER};

class peak_detect
{

private:
  float avg;
  float rise;
  float fall;
  float alpha;
  float peak_value;
  detector_states state;
//  FILE *fdata;
//  FILE *favg;
  

public:
//  ~peak_detect();
  peak_detect(float rise_in, float fall_in, float alpha_in);
  detector_states detect(const float data);
  void set_alpha(float in){alpha=in;}
  void set_rise(float in){rise = in;}
  void set_fall(float in){fall = in;}
  void seed_avg(float in){avg = in;}

};
