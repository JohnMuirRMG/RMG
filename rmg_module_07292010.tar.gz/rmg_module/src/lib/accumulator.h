/*
Accumulator class implements a circular buffer with a stored value for the sum of the buffer's contents
This is treated as a time-matched filter for use by the detector class
*/
//Todd Borrowman ECE-UIUC 2-21-08

//#include <cstdio>

class accumulator
{
private:
  int size;
  double *buffer;
  double total_sum;
  int index;
  //FILE *fbuffer;

  
public:
  accumulator(int s);
  ~accumulator();
  double add(double in);
  double value();
};
