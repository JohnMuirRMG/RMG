/*
detectmod_detect class implements a detectore module for gnuradio
input - data stream
output - .det files storing individual detected pulses
*/
//Todd Borrowman ECE-UIUC 01/30/08~02/2010


#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#include <detectmod_detect.h>
#include <gr_io_signature.h>
#include <cstdio>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdexcept>
#include <sys/time.h>
#include <string.h>


// win32 (mingw/msvc) specific
#ifdef HAVE_IO_H
#include <io.h>
#endif
#ifdef O_BINARY
#define	OUR_O_BINARY O_BINARY
#else
#define	OUR_O_BINARY 0
#endif

// should be handled via configure
#ifdef O_LARGEFILE
#define	OUR_O_LARGEFILE	O_LARGEFILE
#else
#define	OUR_O_LARGEFILE 0
#endif






//Public constructor used by gnuradio
detectmod_detect_sptr 
detectmod_make_detect (int pulse_width, int save_width, int channels, char *filename, float rate, float center_freq, char use_psd)
{
  return detectmod_detect_sptr (new detectmod_detect (pulse_width, save_width, channels, filename, rate, center_freq, use_psd));
}




//Private constructor used internally
detectmod_detect::detectmod_detect (int pulse_width, int save_width, int channels,char *filename, float r, float center_freq, char use_psd)
  : gr_sync_block ("detectmod_detect",
	      gr_make_io_signature (channels, channels, sizeof (gr_complex)),
	      gr_make_io_signature (0,0,0))
{
  rate = r;
  c_freq = center_freq;
  ch = channels;
  acc_length = pulse_width;//size of the accumulator
  
  
  //length of the file needs to be at least 3 times as long as the pulse to accomidate 
  //the noise covariance calculation
  if(save_width < 3*acc_length){
    save_length = 3*acc_length;
  }
  else{
    save_length = save_width;
  }
  int l = strlen(filename)+1;
  fileprefix = (char *)malloc(l*sizeof(char));
  strcpy(fileprefix,filename);


  p_index = 0;
  state = FILL_ACCUMULATOR;
  fill_counter = -7;
  total = 0.0;
  fill_length = ((int)(0.5*acc_length));
  d_fp = 0;

  
  acc = new accumulator(acc_length);
  save_holder = new circ_buffer(ch, save_length);
  pkdet = new peak_detect(1.1,1.05,.05);

  peak_holder = (gr_complex *)malloc(save_length*ch*sizeof(gr_complex));

  psd = use_psd;

}

//Deconstructor
detectmod_detect::~detectmod_detect(){

  free(fileprefix);
  free(peak_holder);
  delete acc;
  delete save_holder;
  delete pkdet;
}

int 
detectmod_detect::work (int noutput_items,
			       gr_vector_const_void_star &input_items,
			       gr_vector_void_star &output_items)
{
  
  gr_complex *temp = (gr_complex *)malloc(ch*sizeof(gr_complex));

  double r,i,holder_temp;

  detector_states det_state = BELOW_THRESHOLD;

  int sh_index;
  
  
  //Loop through all of the samples
  for (int j=0;j<noutput_items;j++){
    
	//Calculate total power received
    holder_temp=0.0;
    for (int m=0;m<ch;m++){
      temp[m] = ((gr_complex *) input_items[m])[j];
      r=temp[m].real();
      i=temp[m].imag();
      holder_temp+=r*r+i*i;
      
    }
    save_holder->add(temp);


    switch(state){
      
	  //initialize the time-matched filter and circular buffer
      case FILL_ACCUMULATOR:

        total = acc->add(holder_temp);
        sh_index = save_holder->get_index();
        if (sh_index == (save_length-1)){
          state = DETECT;
		  //initial estimate of the noise floor for detector
          pkdet->seed_avg(total);
          printf("%s Seed: %f\n",fileprefix,total);
        }
      break;
    
	  //Run detector
      case DETECT:

        total = acc->add(holder_temp);
        det_state = pkdet->detect(total);
        if(det_state == PEAK){//new temporary peak found
          fill_counter = fill_length+1;
        }
        else if(det_state == TRIGGER){
          state = FILL_BUFFER;
        }
      
        fill_counter--;
		//if the buffer is full but the peak is full, save buffer state and confirm peak
        if (fill_counter == 0 && state!=FILL_BUFFER){
          memcpy(peak_holder, save_holder->get_buffer(),ch*save_length*sizeof(gr_complex));
          p_index=save_holder->get_index();
          state = CONFIRM_PEAK;
        }

      break;      

      //buffer is full, wait for the detector to trigger
      case CONFIRM_PEAK:

        total = acc->add(holder_temp);
        det_state = pkdet->detect(total);
        if(det_state == PEAK){//new temporary peak found
          state = DETECT;
          fill_counter = fill_length;
        }
        else if(det_state == TRIGGER){//peak confirmed
          if(psd == 0 || pulse_shape_discriminator()){//04212009 TAB
            write_data(peak_holder,p_index);//04272009 TAB
          }
          state = DETECT;
        }

      break;

	  //confirmed peak, fill the buffer
      case FILL_BUFFER:

        total = acc->add(holder_temp);
        fill_counter--;
        if (fill_counter <= 0){
          if(psd == 0 || pulse_shape_discriminator()){//04212009 TAB
            write_data(save_holder->get_buffer(),save_holder->get_index());
          }
          state = DETECT;
        }

      break;

    }
  }

  return noutput_items;
}


//Writes the pulse data as a .det file
void detectmod_detect::write_data(gr_complex *data, int index){
  
  printf("Write %s\n",fileprefix);

  //Get time
  struct timeval *tp = (struct timeval *)malloc(sizeof(struct timeval));
  gettimeofday(tp, NULL);
  void *temp;
  struct tm *time_struct = gmtime(&(tp->tv_sec));
  char *time_string = (char *)malloc(40*sizeof(char));
  strftime(time_string,40,"%m%d%Y%H%M%S",time_struct);
  char *u_sec = (char *)malloc(10*sizeof(char));
  sprintf(u_sec,"%.6d",(unsigned int)tp->tv_usec);
  strncat(time_string,u_sec,6);
  int len = strlen(fileprefix)+strlen(time_string)+10;
  
  //filename is the given prefix and the time to the microsecond (false precision)
  char *filename = (char *)malloc(len*sizeof(char));
  sprintf(filename,"%s%s.det",fileprefix,time_string);
  printf("%s\n",fileprefix);

  //open .det file
  if(!open_file(filename))
    return;
  if (!d_fp)
    return;

  //write time as a timeval
  fwrite(tp,sizeof(struct timeval),1,(FILE *)d_fp);
  printf("time: %s :done\n", time_string);

  //unwrap circular buffer and write data to file
  if (index != 0){
    temp = data + (index)*ch;
    fwrite(temp,sizeof(gr_complex),(save_length-index)*ch, (FILE *)d_fp);
    fwrite(data,sizeof(gr_complex),(index)*ch, (FILE *)d_fp);
  }
  else
    fwrite(data,sizeof(gr_complex),index*ch, (FILE *)d_fp);

  //close file and free string variables
  close();
  free(time_string);
  free(filename);
  free(u_sec);
  free(tp);

  return;
}

//opens a file, mostly copied from gnuradio
bool
detectmod_detect::open(const char *filename)
{


  int fd;
  if ((fd = ::open (filename,
		    O_WRONLY|O_CREAT|O_TRUNC|OUR_O_LARGEFILE|OUR_O_BINARY, 0664)) < 0){
    perror (filename);
    return false;
  }

  if (d_fp){		// if we've already got a new one open, close it
    fclose((FILE *) d_fp);
    d_fp = 0;
  }
  
  if ((d_fp = fdopen (fd, "wb")) == NULL){
    perror (filename);
    ::close(fd);		// don't leak file descriptor if fdopen fails.
  }

  return d_fp != 0;
}

//close file
void
detectmod_detect::close()
{
  //omni_mutex_lock	l(d_mutex);	// hold mutex for duration of this function

  if (d_fp){
    fclose((FILE *) d_fp);
    d_fp = 0;
  }
  
}

//opens a .det file and writes the header information
bool detectmod_detect::open_file(const char *filename)
{
    
  if(!open(filename)){
    printf("Can't open file \"%s\"\n",filename);
    return 0;
  }
  else{
    fwrite(&ch,sizeof(int),1,(FILE *)d_fp);
    fwrite(&save_length,sizeof(int),1,(FILE *)d_fp);
    fwrite(&acc_length,sizeof(int),1,(FILE *)d_fp);
    int pulse_start = save_length - acc_length-fill_length;
    fwrite(&pulse_start,sizeof(int),1,(FILE *)d_fp);
    fwrite(&rate,sizeof(float),1,(FILE *)d_fp);
    fwrite(&c_freq,sizeof(float),1,(FILE *)d_fp);
  return 1;
  }

}



bool detectmod_detect::pulse_shape_discriminator(){

  const float MAX_PERCENTAGE = 0.20;
  const int SHAPE_THREASHOLD = 14;


  float *pulse_pwr = new float[acc_length];
  int index = save_holder->get_index();
  gr_complex *pulse_buffer = save_holder->get_buffer();
  int pulse_start = save_length - acc_length-fill_length;
  int j,k;
  float r,i;
  float max_value = 0;
  int count = 0;
  bool result = false;
  for(j = 0; j < acc_length; j++){
    pulse_pwr[j] = 0;
    for(k = 0; k < ch; k++){
      r = pulse_buffer[(j+pulse_start+index)%save_length].real();
      i = pulse_buffer[(j+pulse_start+index)%save_length].imag();
      pulse_pwr[j] += r*r-i*i;
    }
    if(pulse_pwr[j] > max_value)
      max_value = pulse_pwr[j];
  }
  max_value = max_value*MAX_PERCENTAGE;
  for(j = 0; j < acc_length; j++){
    if(pulse_pwr[j] > max_value)
      count++;
  }
  if(count>SHAPE_THREASHOLD)
    result = true;

  delete pulse_pwr;
  return result;

}


//Public call for gnuradio to set the rise factor in the detector
void detectmod_detect::rise_factor(float r)
{
  pkdet->set_rise(r);

  return;
}

//Public call for gnuradio to set the fall factor in the detector
void detectmod_detect::fall_factor(float f)
{
  pkdet->set_fall(f);

  return;
}

//Public call for gnuradio to set the noise floor filter coefficient in the detector
void detectmod_detect::alpha_factor(float a)
{
  pkdet->set_alpha(a);

  return;
}

//Public call for gnuradio to reset the detector
void detectmod_detect::reset()
{
  //flush save buffer if state = FILL_BUFFER?
  state = FILL_ACCUMULATOR;
  fill_counter = -7;

  return;
}
