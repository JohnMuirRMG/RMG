/*
Circ_buffer class implements a circular buffer to store the received signal
*/
//Todd Borrowman ECE-UIUC 2-21-08

#include <circ_buffer.h>
#include <stdlib.h>
#include <string.h>

//Constructor
circ_buffer::circ_buffer(int c,int s){

  ch = c;
  size = s;
  buffer = (gr_complex *)calloc(size*ch,sizeof(gr_complex));
  index = 0;

}

//Destructor
circ_buffer::~circ_buffer(){
  free(buffer);
}

//Adds new values to the buffer
void circ_buffer::add(gr_complex *in){

  memcpy(buffer + index*ch, in, ch*sizeof(gr_complex));
  index ++;
  if(index >= size){
    index = 0;
  }
  
  return;
}

//Returns the current index
int circ_buffer::get_index(){

  return index;
}

//Returns the current buffer contents
//The contents are not re-ordered before the return
gr_complex* circ_buffer::get_buffer(){

  return buffer;
}
