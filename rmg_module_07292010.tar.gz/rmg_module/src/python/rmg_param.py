#rmg_param.py
#Container classes for data that defines the software defined detector backend

#Todd Borrowman ECE-UIUC 02/2010


PULSE, CONT = range(2)#module types used in the channels
ch_type_str = ["Pulse Detector", "Raw Baseband Recording"]

#defines data for a single channel for detection
class channel:

    def __init__(self, name = "default", ch = 0, tx_type = PULSE, pw = 0):
        self.name = name
        self.ch = ch
        self.tx_type = tx_type
        self.pw = pw
        self.cf = 0

    def __str__(self):
        ch_str = "Channel #: %s\nChannel Frequency: %f MHz\n\tName: %s\n\tType: %s\n\tPulse Width: %d ms" % (self.ch, self.cf/1000000, self.name, ch_type_str[self.tx_type], self.pw)
        return ch_str


#defines data for the filterbank and detection channels
class backend:

    def __init__(self, cf = 0.0, lo1 = 0.0, num_banks = 1, ch_bw = 8000.0, directory = "./det_files/"):
        self.cf = cf
        self.num_banks = num_banks
        self.lo1 = lo1
        self.ch_bw = ch_bw
        self.num_ch = 0
        self.channels = []
        self.directory = directory

    def add_ch(self, chan):

        if chan.ch < self.num_banks and chan.ch >= 0:
            self.channels.append(chan)
            self.num_ch += 1
            if chan.ch < self.num_banks/2.0:
                chan.cf = self.ch_bw*chan.ch + self.cf
            else:
                chan.cf = (chan.ch - self.num_banks)*self.ch_bw + self.cf
        else:
            raise ValueError, 'Invalid Channel Number'

    def __str__(self):

        be_str = "Center Frequency: %f MHz\nPLL Frequency: %f MHz\nNumber of Channels: %d\nChannel Bandwidth: %f kHz\nNumber of Occupied Channels: %d" % (self.cf/1000000.0, self.lo1/1000000.0, self.num_banks, self.ch_bw/1000.0, self.num_ch)
        for j in range(self.num_ch):
            be_str += '\n' + str(self.channels[j])
        return be_str
