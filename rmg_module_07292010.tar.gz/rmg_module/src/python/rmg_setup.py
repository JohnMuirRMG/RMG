#rmg_setup.py

#GUI for entering transmitters to be tracked using the RMG

#Todd Borrowman ECE-UIUC 02/2010


import wx
import wx.grid as grd
import rmg_editors
import rmg_validators as rmg_val
import rmg_param
import shelve
import os
import math

transmitter_types = ["Pulse", "Continuous", "Other"]
channel_types = [rmg_param.PULSE, rmg_param.CONT, rmg_param.CONT]
usrp_sampling_rate = 64e6
usrp_max_decimation = 250
class transmitter_sizer(wx.BoxSizer):

    def __init__(self,parent):
        
        wx.BoxSizer.__init__(self,wx.HORIZONTAL)
        self.ID_checkbox = wx.NewId()
        self.checkbox = wx.CheckBox(parent,self.ID_checkbox, size = (50,30))
        self.checkbox.SetValue(True)
        self.Add(self.checkbox,0,wx.CENTER)
        self.ID_name_txt = wx.NewId()
        self.name_txt = wx.TextCtrl(parent,self.ID_name_txt,value = "Name", size = (200,30))
        self.name_val = rmg_val.name_evt(self.name_txt)
        wx.EVT_KILL_FOCUS(self.name_txt, self.name_val.offFocus)
        wx.EVT_SET_FOCUS(self.name_txt, self.name_val.onFocus)
        self.Add(self.name_txt,0,wx.EXPAND)
        self.ID_freq_txt = wx.NewId()
        self.freq_txt = wx.TextCtrl(parent,self.ID_freq_txt,value = "302.000", size = (150,30))
        self.freq_val = rmg_val.freq_evt(self.freq_txt, parent.pa_min, parent.pa_max)
        wx.EVT_KILL_FOCUS(self.freq_txt, self.freq_val.offFocus)
        wx.EVT_SET_FOCUS(self.freq_txt, self.freq_val.onFocus)
        self.Add(self.freq_txt,0,wx.EXPAND)
        self.ID_type_txt = wx.NewId()
        self.type_txt = wx.Choice(parent,self.ID_type_txt, choices = transmitter_types, size = (120,30))
        self.type_txt.SetSelection(0)
        self.Add(self.type_txt,0,wx.EXPAND)
        self.ID_pw_txt = wx.NewId()
        self.pw_txt = wx.TextCtrl(parent,self.ID_pw_txt,value = "20", size = (150,30))
        self.pw_val = rmg_val.pw_evt(self.pw_txt)
        wx.EVT_KILL_FOCUS(self.pw_txt, self.pw_val.offFocus)
        wx.EVT_SET_FOCUS(self.pw_txt, self.pw_val.onFocus)
        self.Add(self.pw_txt,0,wx.EXPAND)
        self.ID_new_tx = wx.NewId()
        self.new_tx = wx.Button(parent, self.ID_new_tx, label = "Add", size = (50,30))
        wx.EVT_BUTTON(parent,self.ID_new_tx, parent.add_new_tx)
        self.Add(self.new_tx)

    def test(self, event):
        print "LOST FOCUS"

   

class tx_table(grd.PyGridTableBase):

    def __init__(self,parent,data):

        self.parent = parent
        self.data = data
        grd.PyGridTableBase.__init__(self)
        self.colLabels = ["Select", "Name", "Frequency in MHz", "Type", "Pulse Width in ms"]
        self.dataTypes = [grd.GRID_VALUE_BOOL, grd.GRID_VALUE_STRING, grd.GRID_VALUE_FLOAT,
                          grd.GRID_VALUE_CHOICE + ":" + ",".join(transmitter_types),
                          grd.GRID_VALUE_NUMBER]
        self.colSizes = [50, 200, 150, 120, 150]


    def GetNumberRows(self):
        return len(self.data)

    def GetNumberCols(self):
        return len(self.data[0])

    def IsEmptyCell(self, row, col):

        try:
            return self.data[row][col]
        except IndexError:
            return True

    def GetValue(self, row, col):
        try:
            return self.data[row][col]
        except IndexError:
            return ""

    def SetValue(self, row, col, value):

        try:
            self.data[row][col] = value
        except IndexError:
            return False

    def GetColLabelValue(self, col):
        return self.colLabels[col]

    def GetTypeName(self,row, col):
        return self.dataTypes[col]

    def CanGetValueAs(self, row, col, typeName):

        colType = self.dataTypes[col].split(':')[0]
        if typeName == colType:
            return True
        else:
            return False

    def CanSetValueAs(self, row, col, typeName):
        return self.CanGetValueAs(row, col, typeName)

    def GetColSize(self, col):
        return self.colSizes[col]

    def AppendRow(self, data):
        self.data.append(data)

    def DeleteRow(self, row):
        del self.data[row]

     

class tx_grid(grd.Grid):

    def __init__(self, parent, ID, data, pa_min, pa_max):

        self.parent = parent
        grd.Grid.__init__(self, parent, ID)
        self.table = tx_table(parent,data)
        self.SetTable(self.table, True)
        self.SetRowLabelSize(0)
        for j in range(self.table.GetNumberCols()):
            self.SetColSize(j, self.table.GetColSize(j))
        name_attr = grd.GridCellAttr()
        name_attr.SetEditor(rmg_editors.name_editor())
        self.SetColAttr(1,name_attr)
        freq_attr = grd.GridCellAttr()
        freq_attr.SetEditor(rmg_editors.freq_editor(pa_min,pa_max))
        self.SetColAttr(2,freq_attr)
        pw_attr = grd.GridCellAttr()
        pw_attr.SetEditor(rmg_editors.pw_editor())
        self.SetColAttr(4,pw_attr)

    def AppendRow(self, data):

        self.table.AppendRow(data)
        self.ProcessTableMessage(grd.GridTableMessage(self.table, grd.GRIDTABLE_NOTIFY_ROWS_APPENDED,1))
        self.AdjustScrollbars()

    def delete_checked(self):

        count = 0;
        numrows = self.table.GetNumberRows()
        for j in range(numrows-1,-1,-1):
            if self.table.GetValue(j,0):
                self.table.DeleteRow(j)
                count+=1
        self.ProcessTableMessage(grd.GridTableMessage(self.table, grd.GRIDTABLE_NOTIFY_ROWS_DELETED,numrows-count,count))
        self.AdjustScrollbars()

    def check_all(self):

        for j in range(self.table.GetNumberRows()):
            self.table.SetValue(j,0,True)
        self.ProcessTableMessage(grd.GridTableMessage(self.table, grd.GRIDTABLE_REQUEST_VIEW_GET_VALUES))

    def uncheck_all(self):

        for j in range(self.table.GetNumberRows()):
            self.table.SetValue(j,0,False)
        self.ProcessTableMessage(grd.GridTableMessage(self.table, grd.GRIDTABLE_REQUEST_VIEW_GET_VALUES))

    def invert_check(self):
        for j in range(self.table.GetNumberRows()):
            self.table.SetValue(j,0,not self.table.GetValue(j,0))
        self.ProcessTableMessage(grd.GridTableMessage(self.table, grd.GRIDTABLE_REQUEST_VIEW_GET_VALUES))

    def replace_data(self, data):

        old_rows = self.table.GetNumberRows()
        new_rows = len(data)
        self.table.data = data
        if old_rows > new_rows:
            self.ProcessTableMessage(grd.GridTableMessage(self.table, grd.GRIDTABLE_NOTIFY_ROWS_DELETED,new_rows,
                                     old_rows-new_rows))
        elif new_rows > old_rows:
            self.ProcessTableMessage(grd.GridTableMessage(self.table, grd.GRIDTABLE_NOTIFY_ROWS_APPENDED,new_rows-old_rows))
        self.ProcessTableMessage(grd.GridTableMessage(self.table, grd.GRIDTABLE_REQUEST_VIEW_GET_VALUES))
        self.AdjustScrollbars()



class rmg_window(wx.Frame):

    def __init__(self, parent, id, title):


        #self.set_defaults()
        wx.Frame.__init__(self,parent,id, title, size=(700,600))
        self.CreateStatusBar()

        self.panel = wx.Panel(self, wx.ID_ANY)

#Menu
        menu_bar = wx.MenuBar()
        file_menu = wx.Menu()
        file_menu.Append(101, "&Load\tCtrl+O")
        file_menu.Append(102, "&Save\tCtrl+S")
        file_menu.AppendSeparator()
        file_menu.Append(103, "&Close\tAlt+F4")
        menu_bar.Append(file_menu, "&File")
        help_menu = wx.Menu()
        help_menu.Append(201, "&About")
        menu_bar.Append(help_menu, "&Help")
        self.SetMenuBar(menu_bar)
  #Menu Events
        self.Bind(wx.EVT_MENU, self.load_data, id=101)
        self.Bind(wx.EVT_MENU, self.save_data, id=102)
        self.Bind(wx.EVT_MENU, self.menu103, id=103)
        self.Bind(wx.EVT_MENU, self.menu201, id=201)

        self.main_sizer = wx.BoxSizer(wx.VERTICAL)

#front-end params
        self.pa_min = 162000000
        self.pa_max = 167000000
        self.if1_cf = 70000000
        self.if1_bw = 500000
        self.if2_cf = 10700000
        self.if2_bw = 250000
        self.lo2 = 80700000
        self.pv_min = 218500000
        self.pv_max = 248000000
        self.pv_step = 100000
        self.pv_offset = 0#pv_tune + pv_offset = actual frequency output of the pll
        self.num_banks = 32
        
        self.ID_param_txt = wx.NewId()
        self.param_txt = wx.StaticText(self.panel, self.ID_param_txt,label = "", size = (500,130))
        self.main_sizer.Add(self.param_txt,0,wx.EXPAND)
        self.update_param_txt()

#directory
        self.dir_sizer = wx.BoxSizer(wx.HORIZONTAL)
	dir_txt = wx.StaticText(self.panel, wx.NewId(), label = "Directory for .det files", size = (150,30))
        self.dir_sizer.Add(dir_txt)
        self.ID_dir_txtbx = wx.NewId()
        self.dir_txtbx = wx.TextCtrl(self.panel, self.ID_dir_txtbx, os.getcwd(), size = (300,30))
        self.dir_sizer.Add(self.dir_txtbx,1,wx.EXPAND)
        self.ID_dir_button = wx.NewId()
        self.dir_button = wx.Button(self.panel, self.ID_dir_button, label = "...", size = (30,30))
        wx.EVT_BUTTON(self.panel, self.ID_dir_button, self.directory_menu)
        self.dir_sizer.Add(self.dir_button)
        self.main_sizer.Add(self.dir_sizer)


#tx entries
        self.ID_tx_txt = wx.NewId()
        self.tx_txt = wx.StaticText(self.panel,self.ID_tx_txt,label = "Transmitters", size = (100,30))
        self.main_sizer.Add(self.tx_txt,0,wx.CENTER)

        self.ID_grid = wx.NewId()
        self.gr = tx_grid(self.panel, self.ID_grid, [[True, "N",(self.pa_min + self.pa_max)/2000000.0,"Pulse", 20]],self.pa_min, self.pa_max)


        self.main_sizer.Add(self.gr,1,wx.EXPAND)

        #self.add_sizer = transmitter_sizer(self)
        #self.main_sizer.Add(self.add_sizer)

        
#buttons
        self.button_sizer = wx.BoxSizer(wx.HORIZONTAL)
        self.ID_check_all = wx.NewId()
        self.check_all = wx.Button(self.panel, self.ID_check_all, label = "Check All", size = (120,30))
        wx.EVT_BUTTON(self.panel,self.ID_check_all, self.check_all_tx)
        self.button_sizer.Add(self.check_all,3)
        self.ID_uncheck_all = wx.NewId()
        self.uncheck_all = wx.Button(self.panel, self.ID_uncheck_all, label = "Uncheck All", size = (120,30))
        wx.EVT_BUTTON(self.panel,self.ID_uncheck_all, self.uncheck_all_tx)
        self.button_sizer.Add(self.uncheck_all,3)
        self.ID_invert_all = wx.NewId()
        self.invert_all = wx.Button(self.panel, self.ID_invert_all, label = "Invert Selection", size = (120,30))
        wx.EVT_BUTTON(self.panel,self.ID_invert_all, self.invert_all_tx)
        self.button_sizer.Add(self.invert_all,3)

        self.ID_del_tx = wx.NewId()
        self.del_tx = wx.Button(self.panel, self.ID_del_tx, label = "Delete Selected", size = (120,30))
        wx.EVT_BUTTON(self.panel,self.ID_del_tx, self.del_sel_tx)
        self.button_sizer.Add(self.del_tx,3)
        self.ID_new_tx = wx.NewId()
        self.new_tx = wx.Button(self.panel, self.ID_new_tx, label = "Add New Transmitter", size = (200,30))
        wx.EVT_BUTTON(self.panel, self.ID_new_tx, self.add_new_tx)
        self.button_sizer.Add(self.new_tx,5)
        self.ID_calc = wx.NewId()
        self.calc = wx.Button(self.panel, self.ID_calc, label = "Calculate Tuning", size = (200,30))
        wx.EVT_BUTTON(self.panel,self.ID_calc, self.calc_tune)
        self.button_sizer.Add(self.calc,5)
        
        self.main_sizer.Add(self.button_sizer,0,wx.CENTER)

        self.panel.SetSizer(self.main_sizer)
        #self.SetAutoLayout(True)
        self.main_sizer.Fit(self)

        self.Show(True)

    def directory_menu(self, event):
        curr_dir = self.dir_txtbx.Value
        if not os.path.exists(curr_dir):
            curr_dir = os.getcwd()
        dlg = wx.DirDialog(self, "Location to save \".det\" files", curr_dir)
        if dlg.ShowModal() == wx.ID_OK:
            self.dir_txtbx.SetValue(dlg.GetPath())
        #dlg.destroy()

    def add_new_tx(self, event):

        checkbox_value = True#self.add_sizer.checkbox.GetValue()
        name = "default"#self.add_sizer.name_txt.GetValue()
        freq = (self.pa_min + self.pa_max)/2000000.0#float(self.add_sizer.freq_txt.GetValue())
        tx_type = transmitter_types[0]#transmitter_types[self.add_sizer.type_txt.GetSelection()]
        pw = 20#int(self.add_sizer.pw_txt.GetValue())

        self.gr.AppendRow([checkbox_value, name, freq, tx_type, pw])

    def check_all_tx(self, event):

        self.gr.check_all()

    def uncheck_all_tx(self, event):

        self.gr.uncheck_all()

    def invert_all_tx(self, event):

        self.gr.invert_check()

    def del_sel_tx(self, event):
        
        self.gr.delete_checked()


    def load_data(self, event):
        dlg = wx.FileDialog(self, "Load .dat file", os.getcwd(), "default.dat", "*.dat", wx.OPEN | wx.CHANGE_DIR)
        if dlg.ShowModal() == wx.ID_OK:
            path = dlg.GetPath()
            #load_file = open(path,'r')
        #self.gr = tx_grid(self, self.ID_grid, pickle.load(load_file))
            #self.gr.replace_data(pickle.load(load_file))
            #load_file.close()
            self.SetStatusText(dlg.GetFilename())
            dshelf = shelve.open(path)
            self.pa_min = dshelf["pa_min"]
            self.pa_max = dshelf["pa_max"]
            self.if1_cf = dshelf["if1_cf"]
            self.if1_bw = dshelf["if1_bw"]
            self.if2_cf = dshelf["if2_cf"]
            self.if2_bw = dshelf["if2_bw"]
            self.lo2 = dshelf["lo2"]
            self.pv_min = dshelf["pv_min"]
            self.pv_max = dshelf["pv_max"]
            self.pv_step = dshelf["pv_step"]
            self.pv_offset = dshelf["pv_offset"]
            self.gr.replace_data(dshelf["data"])
            self.num_banks = dshelf["num_banks"]
            self.dir_txtbx.SetValue(dshelf["curr_dir"])
            dshelf.close()
            self.update_param_txt()
        dlg.Destroy()

    def update_param_txt(self):
            param_str = "Front-End Frequency Parameters\nPreAmp - Minimum Frequency: %f MHz, Maximum Frequency: %f MHz\nFirst IF Stage - Center Frequency: %f MHz, Bandwidth: %f kHz\nSecond LO Frequency: %f MHz\nSecond IF Stage - Center Frequency: %f MHz, Bandwidth: %f kHz\nPLL/VCO Tuning Range - Min: %f MHz, Max: %f MHz, Step: %f kHz, Offset: %f kHz\nNumber of Baseband Channels: %d" %(self.pa_min/1000000.0, self.pa_max/1000000.0, self.if1_cf/1000000.0, self.if1_bw/1000.0, self.lo2/1000000.0, self.if2_cf/1000000.0, self.if2_bw/1000.0, self.pv_min/1000000.0, self.pv_max/1000000.0, self.pv_step/1000.0, self.pv_offset/1000.0, self.num_banks)
            self.param_txt.SetLabel(param_str)        

    def save_data(self, event):
        dlg = wx.FileDialog(self, "Save file as ...", os.getcwd(), "default.dat", "*.dat", wx.SAVE)
        if dlg.ShowModal() == wx.ID_OK:
            path = dlg.GetPath()
            #save_file = open(path,'w')
            #pickle.dump(self.gr.table.data, save_file)
            #save_file.close()
            self.SetStatusText(dlg.GetFilename())
            dshelf = shelve.open(path)
            dshelf["data"] = self.gr.table.data
            dshelf["pa_min"] = self.pa_min
            dshelf["pa_max"] = self.pa_max
            dshelf["if1_cf"] = self.if1_cf
            dshelf["if1_bw"] = self.if1_bw
            dshelf["if2_cf"] = self.if2_cf
            dshelf["if2_bw"] = self.if2_bw
            dshelf["lo2"] = self.lo2
            dshelf["pv_min"] = self.pv_min
            dshelf["pv_max"] = self.pv_max
            dshelf["pv_step"] = self.pv_step
            dshelf["pv_offset"] = self.pv_offset
            dshelf["num_banks"] = self.num_banks
            dshelf["curr_dir"] = self.dir_txtbx.Value
            dshelf.close()
        dlg.Destroy()

    def menu103(self, event):
        self.Close()

    def menu201(self, event):
        wx.MessageDialog(self, "This program determines the necessary set-up parameters to run the RMG Receiver.\n\nDept. of Electrical and Computer Engineering\nUniversity of Illinois, Urbana-Champaign\nWritten by Todd Borrowman\nMarch 2010",
                                 "About",wx.OK).ShowModal()

    def calc_tune(self,event):
        print "Calculating Tuning"
        self.lo_calc()
        self.backend_calc()
        self.display_tx()

    def lo_calc(self):

        self.if_max = self.lo2 - (self.if2_cf - self.if2_bw/2.0)
        if self.if_max > self.if1_cf + self.if1_bw/2.0:
            self.if_max = self.if1_cf + self.if1_bw/2.0
        self.if_min = self.lo2 - (self.if2_cf + self.if2_bw/2.0)
        if self.if_min > self.if1_cf + self.if1_bw/2.0:
            self.if_min = self.if1_cf + self.if1_bw/2.0

        actual_pv_min = self.pv_min + self.pv_offset
        actual_pv_max = self.pv_max + self.pv_offset

        self.high_lo = True
        if self.pa_min > self.if_max + actual_pv_min:
            self.high_lo = False
        
        bandwidth = self.if_max - self.if_min
        decim = math.floor(usrp_sampling_rate / (self.num_banks/(self.num_banks-1)*bandwidth))
        if decim > usrp_max_decimation:
            decim = usrp_max_decimation
        self.ch_bw = usrp_sampling_rate / decim / self.num_banks
        self.decim = decim

        print self.ch_bw, self.decim
        
        

    def backend_calc(self):
    
        data = self.gr.table.data

        num_freqs = len(data)
        freqs = []
        freq_tune = []
        for j in range(num_freqs):
            if data[j][0]:
                curr_freq = int(data[j][2]*1000000)#change this so it finds the freq col dynamically
                freqs.append(curr_freq)
        #freq_tune.Append([])

#added independent subgroup seperator TAB04062010


        
        s_freqs = sorted(freqs)
        max_steps = []

        for j in s_freqs:
                if not self.high_lo:
                    #high_lo = False
                    max_tune = j - self.if_min - self.pv_offset
                    min_tune = j - self.if_max - self.pv_offset
        
                    if max_tune > self.pv_max:
                        max_tune = self.pv_max
                    if min_tune < self.pv_min:
                        min_tune = self.pv_min


                else:
                    #high_lo = True
                    max_tune = j + self.if_max - self.pv_offset
                    min_tune = j + self.if_min - self.pv_offset
                    if max_tune > self.pv_max:
                        max_tune = self.pv_max
                    if min_tune < self.pv_min:
                        min_tune = self.pv_min

            #    for m in range(min_tune//self.pv_step + 1, max_tune//self.pv_step +1):
             #       if not self.high_lo:
              #          baseband_cf = (self.lo2 - self.if2_cf) + m*self.pv_step + self.pv_offset
               #         baseband_freq = curr_freq - baseband_cf
                    
                min_steps = int(math.ceil(min_tune/self.pv_step))
                max_steps.append(int(math.floor(max_tune/self.pv_step)))
                freq_tune.append(set(range(min_steps, max_steps[-1] +1)))
                
        num_freqs = len(s_freqs)
        super_set = set()
        #print "Build superset:", num_freqs
        for j in range(num_freqs):
            super_set.update(freq_tune[j])
        inv = dict()
        cp_ss = super_set.copy()
        #print "Build inversion dict:", len(super_set)
        for j in range(len(super_set)):
            temp_tune = cp_ss.pop()
            inv[temp_tune] = set()
            for k in range(num_freqs):
                if temp_tune in freq_tune[k]:
                    inv[temp_tune].add(s_freqs[k])
        save_keys = []
        f_index = 0
        while num_freqs > f_index:
            save_keys.append(max_steps[f_index])
            f_index += len(inv[max_steps[f_index]])
            
        print save_keys
        for j in save_keys:
            print inv[j]
        #exit()


        #(min_sets, max_tx, save_keys) = self.smallest_set(inv, set(freqs))

        self.backends = []
        for j in save_keys:
            lo1 = j*self.pv_step
            if self.high_lo:
                center_freq = lo1 + self.pv_offset - (self.lo2 - self.if2_cf)
            else:
                center_freq = lo1 + self.pv_offset + (self.lo2 - self.if2_cf)
            curr_be = rmg_param.backend(center_freq, lo1, self.num_banks, self.ch_bw, self.dir_txtbx.Value)
            for k in range(len(inv[j])):
                curr_freq = inv[j].pop()
                index = freqs.index(curr_freq)
                ch_type = channel_types[transmitter_types.index(data[index][3])]

                baseband_freq = curr_freq - center_freq
                baseband_ch = round(baseband_freq/self.ch_bw)
                if baseband_ch >=0:
                    ch_num = int(baseband_ch)
                else:
                    ch_num = int(self.num_banks + baseband_ch)
                print ch_num, baseband_ch, curr_freq, lo1, inv[j], j
                curr_ch = rmg_param.channel(data[index][1], ch_num, ch_type, data[index][4])
                curr_be.add_ch(curr_ch)

            self.backends.append(curr_be)
        dlg = wx.FileDialog(self, "Save config as ...", os.getcwd(), "default.dfc", "*.dfc", wx.SAVE)
        if dlg.ShowModal() == wx.ID_OK:
            path = dlg.GetPath()
            dshelf = shelve.open(path)
            dshelf["backends"] = self.backends
            dshelf["high_lo"] = self.high_lo
            dshelf["decim"] = self.decim
            dshelf.close()
        dlg.Destroy()

#I no longer use this. Probably can be removed
    def smallest_set(self, inv_dict, super_set):
        #print "First Loop:", len(inv_dict.keys())
        #raw_input()
        min_sets = 1000000
        max_tx = 0
        save_keys = []
        
        for j in inv_dict.keys():
            #print j, super_set & set([j])
            if len(super_set.intersection(inv_dict[j])) > 0 :
                #print "intersection"
                cp_inv = inv_dict.copy()
                del cp_inv[j]
                cp_ss = super_set.difference(inv_dict[j])

                if len(cp_ss) > 0:
                    (num_sets, num_tx, keys) = self.smallest_set(cp_inv, cp_ss)
                    num_sets += 1
                    num_tx += len(inv_dict[j])
                    keys += [j]
                else:
                    num_sets = 1
                    num_tx = len(inv_dict[j])
                    keys = [j]
                if num_sets < min_sets or (num_sets == min_sets and num_tx > max_tx):
                    min_sets = num_sets
                    max_tx = num_tx
                    save_keys = keys
        return (min_sets, max_tx, save_keys)

    def display_tx(self):
        for j in self.backends:
            print j



if __name__ == "__main__":
    app = wx.PySimpleApp()
    frame = rmg_window(None, wx.ID_ANY, "Direction Finder Configure")

    app.MainLoop()
