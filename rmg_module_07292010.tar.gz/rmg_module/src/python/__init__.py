# make this a package
import rmg_run
import rmg_setup
