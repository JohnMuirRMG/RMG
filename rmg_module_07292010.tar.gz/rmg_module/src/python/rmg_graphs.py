#rmg_graphs.py
#defines the GNU Radio graphs for the software defined detection backend

#Todd Borrowman ECE-UIUC 02/2010


from gnuradio import gr, blks2, usrp, gru
from detectmod import detect
import rmg_param
import sys, time


#defines the USRP interface to get data off of the RMG receiver
class usrp_top_block(gr.top_block):
	def __init__(self, fpga_frequency = -10.7e6, decim_factor = 250, channels = 4):
		gr.top_block.__init__(self)

		self.channels = channels
		self.usb_rate = 64e6 / decim_factor
		#Setup USRP
		self.u = usrp.source_c(0, decim_factor, fpga_filename="std_4rx_0tx.rbf")
		#usrp.source_c(which_board,decimation,channels,mux,mode,fusb_block_size,fusb_nblocks,fpga_filename,firmware_filename)
                #print dir(self.u)
		#checks that there are enough A/D channels
		if self.u.nddcs() < self.channels:
            		sys.stderr.write('This code requires an FPGA build with %d DDCs.  This FPGA has only %d.\n' % (
                		self.channels, self.u.nddcs()))
            		raise SystemExit
                             
        	if not self.u.set_nchannels(self.channels):
            		sys.stderr.write('set_n.channels(%d) failed\n' % (self.channels,))
            		raise SystemExit
        
        	self.u.set_mux(gru.hexint(0xf3f2f1f0))
	
                self.u.set_rx_freq(0,fpga_frequency)
                self.u.set_rx_freq(1,fpga_frequency)
                self.u.set_rx_freq(2,fpga_frequency)
                self.u.set_rx_freq(3,fpga_frequency)
                
                
#defines the software filter and detectors
class software_backend(gr.hier_block2):

    def __init__(self, channels, be_param):

        gr.hier_block2.__init__(self, "software_backend",
                                gr.io_signature(1, 1, gr.sizeof_gr_complex), # Input signature
                                gr.io_signature(0, 0, 0))             # Output signature

        nbank = be_param.num_banks

        di = gr.deinterleave(gr.sizeof_gr_complex)
        self.connect(self, di)
	
	#calculate the filter for the polyphase filter
        chan_rate = be_param.ch_bw
	print "Channel sampling rate :",chan_rate
        taps = gr.firdes.low_pass(1.0, 
                                  chan_rate*be_param.num_banks, 
                                  0.4*chan_rate , 
                                  0.1*chan_rate ,
                                  gr.firdes.WIN_HANN)
        print "Channel filter has", len(taps), "taps"

        #build filterbanks for each RF channel
        self.bank = []

        for j in range(channels):
	    self.bank += [blks2.analysis_filterbank(nbank,taps)]

            #self.bank += [gr.pfb_channelizer_ccf(nbank,taps)]
            self.connect((di,j), self.bank[j])
    	self.det = []
        self.det_channels = []
        self.fs = []
        self.fs_channels = []

        #build detectors et al for each filtered channel
	for j in be_param.channels:

            print j
            if j.tx_type == rmg_param.PULSE:


                filter_length = int(round(j.pw*chan_rate/1000))

                
                new_det = detect(filter_length,filter_length*3,channels, str(be_param.directory + '/' + str(j.name)), chan_rate, j.cf, 0)

                new_det.rise_factor(1.2)
                new_det.fall_factor(1.1)
                new_det.alpha_factor(0.01)
                self.det.append(new_det)

                for k in range(channels):
		    self.connect((self.bank[k],j.ch),(new_det,k))
                self.det_channels.append(j.ch)

            elif j.tx_type == rmg_param.CONT:

                # Pick up current localtime
                localtime=time.localtime()

                # Generate filename
                filename="%04d%02d%02d%02d%02d%02d.tdat" % \
                         (localtime.tm_year, localtime.tm_mon, localtime.tm_mday, 
	                  localtime.tm_hour, localtime.tm_min, localtime.tm_sec)

                new_fs = gr.file_sink(gr.sizeof_gr_complex, str(be_param.directory + str(j.name) + filename))
                inter = gr.interleave(gr.sizeof_gr_complex)
                for k in range(channels):
                    self.connect((self.bank[k],j.ch), (inter, k))
                self.connect(inter, new_fs)
                self.fs.append(new_fs)
                self.fs_channels.append(j)

        #print self.det_channels
        #throwaway any non-used filtered channels
        for j in range(nbank):
            if not j in self.det_channels:#FIXME this doesn't work with continuous TAB04092010
                for k in range(channels):
                    #print "Null Sink det_channel ", j, " and rf_channel ", k
                    self.connect((self.bank[k],j),gr.null_sink(gr.sizeof_gr_complex))
            #else:
                #print "THIS CHANNEL NOT NULL", j
                    

    def reset(self):
        #detectors
        for j in range(len(self.det)):
            self.det[j].reset()
        #file_sinks
        for j in range(len(self.fs)):

            # Pick up current localtime
            localtime=time.localtime()

            # Generate filename
            filename="%04d%02d%02d%02d%02d%02d.tdat" % \
                         (localtime.tm_year, localtime.tm_mon, localtime.tm_mday, 
	                  localtime.tm_hour, localtime.tm_min, localtime.tm_sec)

            self.fs[j].open(str(self.fs_channels[j].name) + filename)


#defines a null front-end for testing without usrp
class no_usrp_top_block(gr.top_block):
	def __init__(self, fpga_frequency = -10.7e6, decim_factor = 250, channels = 4):
		gr.top_block.__init__(self)
                self.u = gr.null_source(gr.sizeof_gr_complex)
