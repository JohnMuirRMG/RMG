
import rmg_graphs, rmg_param
from rmg_pic_interface import rmg_pic_interface
import shelve, os
import time


FPGA_FREQ = 10.7e6
CHANNELS = 4
#ALLOW_NO_PIC_COMMUNICATION = 0#set to 1 to ignore rs232 errors

class detector_array:

    def __init__(self,filename = "default.dfc", ALLOW_NO_PIC_COMMUNICATION = 0):
        self.high_lo = False
        self.decim = 250#editted for checking 08312009 TAB
        self.backend_param = []
        self.frontend = None
        self.backends = []
        self.num_be = 0
        self.connected_be = 0
        self.sc = rmg_pic_interface()
        self.create_graph(filename, ALLOW_NO_PIC_COMMUNICATION)

    def create_graph(self, filename = "default.dfc", ALLOW_NO_PIC_COMMUNICATION = 0):
        self.load_param(filename)
        self.create_frontend()
        #self.create_backends()
        self.create_backend(0)
        #self.frontend.connect(self.frontend.u, self.backends[self.connected_be])
        self.frontend.connect(self.frontend.u, self.backend)
        try:        
            self.sc.tune(self.backend_param[self.connected_be].lo1)
        except ValueError:
            if ALLOW_NO_PIC_COMMUNICATION:
                    print "No serial connection.  Ignoring for testing"
                    self.sc = None
            else:
	        raise IOError, 'Could not communicate with PIC to tune LO1'

    def load_param(self,filename):
#ADD Error checking to filename!!!!!!!!!!!!!!!!!!!!
        if filename.find('.dfc') == -1:
            raise ValueError, "Invalid Filename"
        dshelf = shelve.open(filename)
        try:
            self.high_lo = dshelf["high_lo"]
        except KeyError:
            raise ValueError, "File %s doesn't contain configuration data" % (filename,)
        self.decim = 250#dshelf["decim"]
        self.backend_param = dshelf["backends"]
        dshelf.close()
        self.num_be = len(self.backend_param)
        if self.sc != None:
            if self.high_lo:
                self.sc.use_high_lo()
            else:
                self.sc.use_low_lo()

    def create_frontend(self):
        if self.high_lo:
           lo3 = FPGA_FREQ
        else:
           lo3 = -FPGA_FREQ

        self.frontend = rmg_graphs.usrp_top_block(lo3, int(self.decim), CHANNELS)

    def create_backends(self):
        for j in self.backend_param:
            self.backends.append(rmg_graphs.software_backend(CHANNELS, j))
            if not os.path.exists(j.directory):
                print 'Making directory: %s' % (j.directory,)
                os.makedirs(j.directory)

    def create_backend(self, n):
        self.backend = rmg_graphs.software_backend(CHANNELS, self.backend_param[n])
        if not os.path.exists(self.backend_param[n].directory):
                print 'Making directory: %s' % (self.backend_param[n].directory,)
                os.makedirs(self.backend_param[n].directory)
            
    def next(self):

        #self.frontend.disconnect(self.frontend.u, self.backends[self.connected_be])
        self.frontend.disconnect(self.frontend.u, self.backend)
        del self.backend
        self.connected_be += 1
        if self.connected_be == self.num_be:
            self.connected_be = 0
        self.create_backend(self.connected_be)
        #self.frontend.connect(self.frontend.u, self.backends[self.connected_be])
        self.frontend.connect(self.frontend.u, self.backend)
        if self.sc != None:
            self.sc.tune(self.backend_param[self.connected_be].lo1)

    def stop(self):
        self.frontend.stop()
	self.frontend.wait()
    def start(self):
        #self.backends[self.connected_be].reset()
        self.backend.reset()
        self.frontend.start()

    def run(self,sleep_sec = 10):
        while(1):
            try:

                self.start()
                time.sleep(sleep_sec)
                self.stop()
                self.next()
            except KeyboardInterrupt:

                self.stop()
                if self.sc != None:
                    del self.sc
                break


if __name__ == '__main__':

    
    dir_finder = detector_array()
    dir_finder.run()
